// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityNodeInfoCompat

public static class <init>
{

    private final Object mAction;

    public int getId()
    {
        return etId(mAction);
    }

    public CharSequence getLabel()
    {
        return etLabel(mAction);
    }

    private a(Object obj)
    {
        mAction = obj;
    }

    mAction(Object obj, mAction maction)
    {
        this(obj);
    }
}
