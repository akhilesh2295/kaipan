// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityNodeInfoCompatKitKat

static class 
{

    static int getColumnCount(Object obj)
    {
        return ((android.view.accessibility.ectionInfo)obj).nt();
    }

    static int getRowCount(Object obj)
    {
        return ((android.view.accessibility.nt)obj).nt();
    }

    static boolean isHierarchical(Object obj)
    {
        return ((android.view.accessibility.nt)obj).al();
    }

    ()
    {
    }
}
