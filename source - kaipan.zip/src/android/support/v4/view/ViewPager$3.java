// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;


// Referenced classes of package android.support.v4.view:
//            ViewPager

class this._cls0
    implements Runnable
{

    final ViewPager this$0;

    public void run()
    {
        ViewPager.access$000(ViewPager.this, 0);
        populate();
    }

    ()
    {
        this$0 = ViewPager.this;
        super();
    }
}
