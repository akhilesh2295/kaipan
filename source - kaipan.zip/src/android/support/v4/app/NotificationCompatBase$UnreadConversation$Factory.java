// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.app.PendingIntent;

// Referenced classes of package android.support.v4.app:
//            NotificationCompatBase

public static interface 
{

    public abstract  build(String as[],  , PendingIntent pendingintent, PendingIntent pendingintent1, String as1[], long l);
}
