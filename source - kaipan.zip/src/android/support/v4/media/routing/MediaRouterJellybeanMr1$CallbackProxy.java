// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.media.routing;

import android.media.MediaRouter;

// Referenced classes of package android.support.v4.media.routing:
//            MediaRouterJellybeanMr1

static class it> extends it>
{

    public void onRoutePresentationDisplayChanged(MediaRouter mediarouter, android.media.nMr1.CallbackProxy callbackproxy)
    {
        ((it>)mCallback).tePresentationDisplayChanged(callbackproxy);
    }

    public ( )
    {
        super();
    }
}
