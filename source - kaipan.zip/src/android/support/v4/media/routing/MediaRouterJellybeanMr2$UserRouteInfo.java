// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.media.routing;


// Referenced classes of package android.support.v4.media.routing:
//            MediaRouterJellybeanMr2

public static final class 
{

    public static void setDescription(Object obj, CharSequence charsequence)
    {
        ((android.media.nMr2.UserRouteInfo)obj).on(charsequence);
    }

    public ()
    {
    }
}
