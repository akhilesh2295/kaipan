// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.media.routing;

import android.view.Display;

// Referenced classes of package android.support.v4.media.routing:
//            MediaRouterJellybeanMr1

public static final class 
{

    public static Display getPresentationDisplay(Object obj)
    {
        return ((android.media.ybeanMr1.RouteInfo)obj).ionDisplay();
    }

    public static boolean isEnabled(Object obj)
    {
        return ((android.media.ionDisplay)obj).ionDisplay();
    }

    public ()
    {
    }
}
