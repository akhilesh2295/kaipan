// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.VolumeProviderCompat;

// Referenced classes of package android.support.v4.media.session:
//            MediaSessionCompat, PlaybackStateCompat

static class 
    implements 
{

    public Object getMediaSession()
    {
        return null;
    }

    public  getSessionToken()
    {
        return null;
    }

    public boolean isActive()
    {
        return false;
    }

    public void release()
    {
    }

    public void sendSessionEvent(String s, Bundle bundle)
    {
    }

    public void setActive(boolean flag)
    {
    }

    public void setCallback( , Handler handler)
    {
    }

    public void setFlags(int i)
    {
    }

    public void setMetadata(MediaMetadataCompat mediametadatacompat)
    {
    }

    public void setPlaybackState(PlaybackStateCompat playbackstatecompat)
    {
    }

    public void setPlaybackToLocal(int i)
    {
    }

    public void setPlaybackToRemote(VolumeProviderCompat volumeprovidercompat)
    {
    }

    ()
    {
    }
}
