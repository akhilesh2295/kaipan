// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.media.session;

import android.media.Rating;

// Referenced classes of package android.support.v4.media.session:
//            MediaControllerCompatApi21

public static class 
{

    public static void fastForward(Object obj)
    {
        ((android.media.session.rtControls)obj).();
    }

    public static void pause(Object obj)
    {
        ((android.media.session.)obj).();
    }

    public static void play(Object obj)
    {
        ((android.media.session.)obj).();
    }

    public static void rewind(Object obj)
    {
        ((android.media.session.)obj).();
    }

    public static void seekTo(Object obj, long l)
    {
        ((android.media.session.)obj).(l);
    }

    public static void setRating(Object obj, Object obj1)
    {
        ((android.media.session.)obj).((Rating)obj1);
    }

    public static void skipToNext(Object obj)
    {
        ((android.media.session.)obj).();
    }

    public static void skipToPrevious(Object obj)
    {
        ((android.media.session.)obj).ous();
    }

    public static void stop(Object obj)
    {
        ((android.media.session.ous)obj).ous();
    }

    public ()
    {
    }
}
