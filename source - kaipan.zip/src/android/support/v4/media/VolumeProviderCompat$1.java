// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.media;


// Referenced classes of package android.support.v4.media:
//            VolumeProviderCompat

class this._cls0
    implements Delegate
{

    final VolumeProviderCompat this$0;

    public void onAdjustVolume(int i)
    {
        VolumeProviderCompat.this.onAdjustVolume(i);
    }

    public void onSetVolumeTo(int i)
    {
        VolumeProviderCompat.this.onSetVolumeTo(i);
    }

    _cls21.Delegate()
    {
        this$0 = VolumeProviderCompat.this;
        super();
    }
}
