// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


public final class R
{
    public static final class anim
    {

        public static final int abc_fade_in = 0x7f040000;
        public static final int abc_fade_out = 0x7f040001;
        public static final int abc_slide_in_bottom = 0x7f040002;
        public static final int abc_slide_in_top = 0x7f040003;
        public static final int abc_slide_out_bottom = 0x7f040004;
        public static final int abc_slide_out_top = 0x7f040005;

        public anim()
        {
        }
    }

    public static final class array
    {

        public static final int cuisines = 0x7f050000;

        public array()
        {
        }
    }

    public static final class attr
    {

        public static final int actionBarDivider = 0x7f01005a;
        public static final int actionBarItemBackground = 0x7f01005b;
        public static final int actionBarPopupTheme = 0x7f010054;
        public static final int actionBarSize = 0x7f010059;
        public static final int actionBarSplitStyle = 0x7f010056;
        public static final int actionBarStyle = 0x7f010055;
        public static final int actionBarTabBarStyle = 0x7f010050;
        public static final int actionBarTabStyle = 0x7f01004f;
        public static final int actionBarTabTextStyle = 0x7f010051;
        public static final int actionBarTheme = 0x7f010057;
        public static final int actionBarWidgetTheme = 0x7f010058;
        public static final int actionButtonStyle = 0x7f010072;
        public static final int actionDropDownStyle = 0x7f01006d;
        public static final int actionLayout = 0x7f01002c;
        public static final int actionMenuTextAppearance = 0x7f01005c;
        public static final int actionMenuTextColor = 0x7f01005d;
        public static final int actionModeBackground = 0x7f010060;
        public static final int actionModeCloseButtonStyle = 0x7f01005f;
        public static final int actionModeCloseDrawable = 0x7f010062;
        public static final int actionModeCopyDrawable = 0x7f010064;
        public static final int actionModeCutDrawable = 0x7f010063;
        public static final int actionModeFindDrawable = 0x7f010068;
        public static final int actionModePasteDrawable = 0x7f010065;
        public static final int actionModePopupWindowStyle = 0x7f01006a;
        public static final int actionModeSelectAllDrawable = 0x7f010066;
        public static final int actionModeShareDrawable = 0x7f010067;
        public static final int actionModeSplitBackground = 0x7f010061;
        public static final int actionModeStyle = 0x7f01005e;
        public static final int actionModeWebSearchDrawable = 0x7f010069;
        public static final int actionOverflowButtonStyle = 0x7f010052;
        public static final int actionOverflowMenuStyle = 0x7f010053;
        public static final int actionProviderClass = 0x7f01002e;
        public static final int actionViewClass = 0x7f01002d;
        public static final int activityChooserViewStyle = 0x7f010079;
        public static final int background = 0x7f01000c;
        public static final int backgroundSplit = 0x7f01000e;
        public static final int backgroundStacked = 0x7f01000d;
        public static final int barSize = 0x7f010026;
        public static final int buttonBarButtonStyle = 0x7f010074;
        public static final int buttonBarStyle = 0x7f010073;
        public static final int closeIcon = 0x7f010035;
        public static final int closeItemLayout = 0x7f01001c;
        public static final int collapseContentDescription = 0x7f0100a4;
        public static final int collapseIcon = 0x7f0100a3;
        public static final int color = 0x7f010020;
        public static final int colorAccent = 0x7f010094;
        public static final int colorButtonNormal = 0x7f010098;
        public static final int colorControlActivated = 0x7f010096;
        public static final int colorControlHighlight = 0x7f010097;
        public static final int colorControlNormal = 0x7f010095;
        public static final int colorPrimary = 0x7f010092;
        public static final int colorPrimaryDark = 0x7f010093;
        public static final int colorSwitchThumbNormal = 0x7f010099;
        public static final int commitIcon = 0x7f010039;
        public static final int contentInsetEnd = 0x7f010017;
        public static final int contentInsetLeft = 0x7f010018;
        public static final int contentInsetRight = 0x7f010019;
        public static final int contentInsetStart = 0x7f010016;
        public static final int customNavigationLayout = 0x7f01000f;
        public static final int disableChildrenWhenDisabled = 0x7f010040;
        public static final int displayOptions = 0x7f010005;
        public static final int divider = 0x7f01000b;
        public static final int dividerHorizontal = 0x7f010078;
        public static final int dividerPadding = 0x7f01002a;
        public static final int dividerVertical = 0x7f010077;
        public static final int drawableSize = 0x7f010022;
        public static final int drawerArrowStyle = 0x7f010000;
        public static final int dropDownListViewStyle = 0x7f01008a;
        public static final int dropdownListPreferredItemHeight = 0x7f01006e;
        public static final int editTextBackground = 0x7f01007f;
        public static final int editTextColor = 0x7f01007e;
        public static final int elevation = 0x7f01001a;
        public static final int expandActivityOverflowButtonDrawable = 0x7f01001e;
        public static final int gapBetweenBars = 0x7f010023;
        public static final int goIcon = 0x7f010036;
        public static final int height = 0x7f010001;
        public static final int hideOnContentScroll = 0x7f010015;
        public static final int homeAsUpIndicator = 0x7f010071;
        public static final int homeLayout = 0x7f010010;
        public static final int icon = 0x7f010009;
        public static final int iconifiedByDefault = 0x7f010033;
        public static final int indeterminateProgressStyle = 0x7f010012;
        public static final int initialActivityCount = 0x7f01001d;
        public static final int isLightTheme = 0x7f010002;
        public static final int itemPadding = 0x7f010014;
        public static final int layout = 0x7f010032;
        public static final int listChoiceBackgroundIndicator = 0x7f010091;
        public static final int listPopupWindowStyle = 0x7f01008b;
        public static final int listPreferredItemHeight = 0x7f010085;
        public static final int listPreferredItemHeightLarge = 0x7f010087;
        public static final int listPreferredItemHeightSmall = 0x7f010086;
        public static final int listPreferredItemPaddingLeft = 0x7f010088;
        public static final int listPreferredItemPaddingRight = 0x7f010089;
        public static final int logo = 0x7f01000a;
        public static final int maxButtonHeight = 0x7f0100a1;
        public static final int measureWithLargestChild = 0x7f010028;
        public static final int middleBarArrowSize = 0x7f010025;
        public static final int navigationContentDescription = 0x7f0100a6;
        public static final int navigationIcon = 0x7f0100a5;
        public static final int navigationMode = 0x7f010004;
        public static final int overlapAnchor = 0x7f010030;
        public static final int paddingEnd = 0x7f0100a8;
        public static final int paddingStart = 0x7f0100a7;
        public static final int panelBackground = 0x7f01008e;
        public static final int panelMenuListTheme = 0x7f010090;
        public static final int panelMenuListWidth = 0x7f01008f;
        public static final int popupMenuStyle = 0x7f01007c;
        public static final int popupPromptView = 0x7f01003f;
        public static final int popupTheme = 0x7f01001b;
        public static final int popupWindowStyle = 0x7f01007d;
        public static final int preserveIconSpacing = 0x7f01002f;
        public static final int progressBarPadding = 0x7f010013;
        public static final int progressBarStyle = 0x7f010011;
        public static final int prompt = 0x7f01003d;
        public static final int queryBackground = 0x7f01003b;
        public static final int queryHint = 0x7f010034;
        public static final int searchIcon = 0x7f010037;
        public static final int searchViewStyle = 0x7f010084;
        public static final int selectableItemBackground = 0x7f010075;
        public static final int selectableItemBackgroundBorderless = 0x7f010076;
        public static final int showAsAction = 0x7f01002b;
        public static final int showDividers = 0x7f010029;
        public static final int showText = 0x7f010047;
        public static final int spinBars = 0x7f010021;
        public static final int spinnerDropDownItemStyle = 0x7f010070;
        public static final int spinnerMode = 0x7f01003e;
        public static final int spinnerStyle = 0x7f01006f;
        public static final int splitTrack = 0x7f010046;
        public static final int state_above_anchor = 0x7f010031;
        public static final int submitBackground = 0x7f01003c;
        public static final int subtitle = 0x7f010006;
        public static final int subtitleTextAppearance = 0x7f01009b;
        public static final int subtitleTextStyle = 0x7f010008;
        public static final int suggestionRowLayout = 0x7f01003a;
        public static final int switchMinWidth = 0x7f010044;
        public static final int switchPadding = 0x7f010045;
        public static final int switchStyle = 0x7f010080;
        public static final int switchTextAppearance = 0x7f010043;
        public static final int textAllCaps = 0x7f01001f;
        public static final int textAppearanceLargePopupMenu = 0x7f01006b;
        public static final int textAppearanceListItem = 0x7f01008c;
        public static final int textAppearanceListItemSmall = 0x7f01008d;
        public static final int textAppearanceSearchResultSubtitle = 0x7f010082;
        public static final int textAppearanceSearchResultTitle = 0x7f010081;
        public static final int textAppearanceSmallPopupMenu = 0x7f01006c;
        public static final int textColorSearchUrl = 0x7f010083;
        public static final int theme = 0x7f0100a2;
        public static final int thickness = 0x7f010027;
        public static final int thumbTextPadding = 0x7f010042;
        public static final int title = 0x7f010003;
        public static final int titleMarginBottom = 0x7f0100a0;
        public static final int titleMarginEnd = 0x7f01009e;
        public static final int titleMarginStart = 0x7f01009d;
        public static final int titleMarginTop = 0x7f01009f;
        public static final int titleMargins = 0x7f01009c;
        public static final int titleTextAppearance = 0x7f01009a;
        public static final int titleTextStyle = 0x7f010007;
        public static final int toolbarNavigationButtonStyle = 0x7f01007b;
        public static final int toolbarStyle = 0x7f01007a;
        public static final int topBottomBarArrowSize = 0x7f010024;
        public static final int track = 0x7f010041;
        public static final int voiceIcon = 0x7f010038;
        public static final int windowActionBar = 0x7f010048;
        public static final int windowActionBarOverlay = 0x7f010049;
        public static final int windowActionModeOverlay = 0x7f01004a;
        public static final int windowFixedHeightMajor = 0x7f01004e;
        public static final int windowFixedHeightMinor = 0x7f01004c;
        public static final int windowFixedWidthMajor = 0x7f01004b;
        public static final int windowFixedWidthMinor = 0x7f01004d;

        public attr()
        {
        }
    }

    public static final class bool
    {

        public static final int abc_action_bar_embed_tabs = 0x7f060000;
        public static final int abc_action_bar_embed_tabs_pre_jb = 0x7f060001;
        public static final int abc_action_bar_expanded_action_views_exclusive = 0x7f060002;
        public static final int abc_config_actionMenuItemAllCaps = 0x7f060003;
        public static final int abc_config_allowActionMenuItemTextWithIcon = 0x7f060004;
        public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 0x7f060005;

        public bool()
        {
        }
    }

    public static final class color
    {

        public static final int abc_background_cache_hint_selector_material_dark = 0x7f070031;
        public static final int abc_background_cache_hint_selector_material_light = 0x7f070032;
        public static final int abc_input_method_navigation_guard = 0x7f070000;
        public static final int abc_primary_text_disable_only_material_dark = 0x7f070033;
        public static final int abc_primary_text_disable_only_material_light = 0x7f070034;
        public static final int abc_primary_text_material_dark = 0x7f070035;
        public static final int abc_primary_text_material_light = 0x7f070036;
        public static final int abc_search_url_text = 0x7f070037;
        public static final int abc_search_url_text_normal = 0x7f070001;
        public static final int abc_search_url_text_pressed = 0x7f070002;
        public static final int abc_search_url_text_selected = 0x7f070003;
        public static final int abc_secondary_text_material_dark = 0x7f070038;
        public static final int abc_secondary_text_material_light = 0x7f070039;
        public static final int accent_material_dark = 0x7f070004;
        public static final int accent_material_light = 0x7f070005;
        public static final int background_floating_material_dark = 0x7f070006;
        public static final int background_floating_material_light = 0x7f070007;
        public static final int background_material_dark = 0x7f070008;
        public static final int background_material_light = 0x7f070009;
        public static final int bright_foreground_disabled_material_dark = 0x7f07000a;
        public static final int bright_foreground_disabled_material_light = 0x7f07000b;
        public static final int bright_foreground_inverse_material_dark = 0x7f07000c;
        public static final int bright_foreground_inverse_material_light = 0x7f07000d;
        public static final int bright_foreground_material_dark = 0x7f07000e;
        public static final int bright_foreground_material_light = 0x7f07000f;
        public static final int button_material_dark = 0x7f070010;
        public static final int button_material_light = 0x7f070011;
        public static final int dim_foreground_disabled_material_dark = 0x7f070012;
        public static final int dim_foreground_disabled_material_light = 0x7f070013;
        public static final int dim_foreground_material_dark = 0x7f070014;
        public static final int dim_foreground_material_light = 0x7f070015;
        public static final int highlighted_text_material_dark = 0x7f070016;
        public static final int highlighted_text_material_light = 0x7f070017;
        public static final int hint_foreground_material_dark = 0x7f070018;
        public static final int hint_foreground_material_light = 0x7f070019;
        public static final int link_text_material_dark = 0x7f07001a;
        public static final int link_text_material_light = 0x7f07001b;
        public static final int material_blue_grey_800 = 0x7f07001c;
        public static final int material_blue_grey_900 = 0x7f07001d;
        public static final int material_blue_grey_950 = 0x7f07001e;
        public static final int material_deep_teal_200 = 0x7f07001f;
        public static final int material_deep_teal_500 = 0x7f070020;
        public static final int primary_dark_material_dark = 0x7f070021;
        public static final int primary_dark_material_light = 0x7f070022;
        public static final int primary_material_dark = 0x7f070023;
        public static final int primary_material_light = 0x7f070024;
        public static final int primary_text_default_material_dark = 0x7f070025;
        public static final int primary_text_default_material_light = 0x7f070026;
        public static final int primary_text_disabled_material_dark = 0x7f070027;
        public static final int primary_text_disabled_material_light = 0x7f070028;
        public static final int ripple_material_dark = 0x7f070029;
        public static final int ripple_material_light = 0x7f07002a;
        public static final int secondary_text_default_material_dark = 0x7f07002b;
        public static final int secondary_text_default_material_light = 0x7f07002c;
        public static final int secondary_text_disabled_material_dark = 0x7f07002d;
        public static final int secondary_text_disabled_material_light = 0x7f07002e;
        public static final int switch_thumb_normal_material_dark = 0x7f07002f;
        public static final int switch_thumb_normal_material_light = 0x7f070030;

        public color()
        {
        }
    }

    public static final class dimen
    {

        public static final int abc_action_bar_default_height_material = 0x7f080000;
        public static final int abc_action_bar_default_padding_material = 0x7f080001;
        public static final int abc_action_bar_icon_vertical_padding_material = 0x7f080002;
        public static final int abc_action_bar_progress_bar_size = 0x7f080003;
        public static final int abc_action_bar_stacked_max_height = 0x7f080004;
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f080005;
        public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f080006;
        public static final int abc_action_bar_subtitle_top_margin_material = 0x7f080007;
        public static final int abc_action_button_min_height_material = 0x7f080008;
        public static final int abc_action_button_min_width_material = 0x7f080009;
        public static final int abc_action_button_min_width_overflow_material = 0x7f08000a;
        public static final int abc_config_prefDialogWidth = 0x7f08000b;
        public static final int abc_control_inset_material = 0x7f08000c;
        public static final int abc_control_padding_material = 0x7f08000d;
        public static final int abc_dropdownitem_icon_width = 0x7f08000e;
        public static final int abc_dropdownitem_text_padding_left = 0x7f08000f;
        public static final int abc_dropdownitem_text_padding_right = 0x7f080010;
        public static final int abc_panel_menu_list_width = 0x7f080011;
        public static final int abc_search_view_preferred_width = 0x7f080012;
        public static final int abc_search_view_text_min_width = 0x7f080013;
        public static final int abc_text_size_body_1_material = 0x7f080014;
        public static final int abc_text_size_body_2_material = 0x7f080015;
        public static final int abc_text_size_button_material = 0x7f080016;
        public static final int abc_text_size_caption_material = 0x7f080017;
        public static final int abc_text_size_display_1_material = 0x7f080018;
        public static final int abc_text_size_display_2_material = 0x7f080019;
        public static final int abc_text_size_display_3_material = 0x7f08001a;
        public static final int abc_text_size_display_4_material = 0x7f08001b;
        public static final int abc_text_size_headline_material = 0x7f08001c;
        public static final int abc_text_size_large_material = 0x7f08001d;
        public static final int abc_text_size_medium_material = 0x7f08001e;
        public static final int abc_text_size_menu_material = 0x7f08001f;
        public static final int abc_text_size_small_material = 0x7f080020;
        public static final int abc_text_size_subhead_material = 0x7f080021;
        public static final int abc_text_size_subtitle_material_toolbar = 0x7f080022;
        public static final int abc_text_size_title_material = 0x7f080023;
        public static final int abc_text_size_title_material_toolbar = 0x7f080024;
        public static final int activity_horizontal_margin = 0x7f080025;
        public static final int activity_vertical_margin = 0x7f080026;
        public static final int dialog_fixed_height_major = 0x7f080027;
        public static final int dialog_fixed_height_minor = 0x7f080028;
        public static final int dialog_fixed_width_major = 0x7f080029;
        public static final int dialog_fixed_width_minor = 0x7f08002a;
        public static final int disabled_alpha_material_dark = 0x7f08002b;
        public static final int disabled_alpha_material_light = 0x7f08002c;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int abc_ab_share_pack_holo_dark = 0x7f020000;
        public static final int abc_ab_share_pack_holo_light = 0x7f020001;
        public static final int abc_btn_check_material = 0x7f020002;
        public static final int abc_btn_check_to_on_mtrl_000 = 0x7f020003;
        public static final int abc_btn_check_to_on_mtrl_015 = 0x7f020004;
        public static final int abc_btn_radio_material = 0x7f020005;
        public static final int abc_btn_radio_to_on_mtrl_000 = 0x7f020006;
        public static final int abc_btn_radio_to_on_mtrl_015 = 0x7f020007;
        public static final int abc_btn_switch_to_on_mtrl_00001 = 0x7f020008;
        public static final int abc_btn_switch_to_on_mtrl_00012 = 0x7f020009;
        public static final int abc_cab_background_internal_bg = 0x7f02000a;
        public static final int abc_cab_background_top_material = 0x7f02000b;
        public static final int abc_cab_background_top_mtrl_alpha = 0x7f02000c;
        public static final int abc_edit_text_material = 0x7f02000d;
        public static final int abc_ic_ab_back_mtrl_am_alpha = 0x7f02000e;
        public static final int abc_ic_clear_mtrl_alpha = 0x7f02000f;
        public static final int abc_ic_commit_search_api_mtrl_alpha = 0x7f020010;
        public static final int abc_ic_go_search_api_mtrl_alpha = 0x7f020011;
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f020012;
        public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f020013;
        public static final int abc_ic_menu_moreoverflow_mtrl_alpha = 0x7f020014;
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f020015;
        public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f020016;
        public static final int abc_ic_menu_share_mtrl_alpha = 0x7f020017;
        public static final int abc_ic_search_api_mtrl_alpha = 0x7f020018;
        public static final int abc_ic_voice_search_api_mtrl_alpha = 0x7f020019;
        public static final int abc_item_background_holo_dark = 0x7f02001a;
        public static final int abc_item_background_holo_light = 0x7f02001b;
        public static final int abc_list_divider_mtrl_alpha = 0x7f02001c;
        public static final int abc_list_focused_holo = 0x7f02001d;
        public static final int abc_list_longpressed_holo = 0x7f02001e;
        public static final int abc_list_pressed_holo_dark = 0x7f02001f;
        public static final int abc_list_pressed_holo_light = 0x7f020020;
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f020021;
        public static final int abc_list_selector_background_transition_holo_light = 0x7f020022;
        public static final int abc_list_selector_disabled_holo_dark = 0x7f020023;
        public static final int abc_list_selector_disabled_holo_light = 0x7f020024;
        public static final int abc_list_selector_holo_dark = 0x7f020025;
        public static final int abc_list_selector_holo_light = 0x7f020026;
        public static final int abc_menu_hardkey_panel_mtrl_mult = 0x7f020027;
        public static final int abc_popup_background_mtrl_mult = 0x7f020028;
        public static final int abc_spinner_mtrl_am_alpha = 0x7f020029;
        public static final int abc_switch_thumb_material = 0x7f02002a;
        public static final int abc_switch_track_mtrl_alpha = 0x7f02002b;
        public static final int abc_tab_indicator_material = 0x7f02002c;
        public static final int abc_tab_indicator_mtrl_alpha = 0x7f02002d;
        public static final int abc_textfield_activated_mtrl_alpha = 0x7f02002e;
        public static final int abc_textfield_default_mtrl_alpha = 0x7f02002f;
        public static final int abc_textfield_search_activated_mtrl_alpha = 0x7f020030;
        public static final int abc_textfield_search_default_mtrl_alpha = 0x7f020031;
        public static final int abc_textfield_search_material = 0x7f020032;
        public static final int ic_launcher = 0x7f020033;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int action_bar = 0x7f090031;
        public static final int action_bar_activity_content = 0x7f090000;
        public static final int action_bar_container = 0x7f090030;
        public static final int action_bar_root = 0x7f09002c;
        public static final int action_bar_spinner = 0x7f090001;
        public static final int action_bar_subtitle = 0x7f09001f;
        public static final int action_bar_title = 0x7f09001e;
        public static final int action_context_bar = 0x7f090032;
        public static final int action_menu_divider = 0x7f090002;
        public static final int action_menu_presenter = 0x7f090003;
        public static final int action_mode_bar = 0x7f09002e;
        public static final int action_mode_bar_stub = 0x7f09002d;
        public static final int action_mode_close_button = 0x7f090020;
        public static final int action_settings = 0x7f090043;
        public static final int activity_chooser_view_content = 0x7f090021;
        public static final int always = 0x7f090016;
        public static final int beginning = 0x7f090013;
        public static final int button = 0x7f090041;
        public static final int checkbox = 0x7f090029;
        public static final int collapseActionView = 0x7f090017;
        public static final int decor_content_parent = 0x7f09002f;
        public static final int default_activity_button = 0x7f090024;
        public static final int dialog = 0x7f09001b;
        public static final int disableHome = 0x7f09000c;
        public static final int dropdown = 0x7f09001c;
        public static final int edit_query = 0x7f090033;
        public static final int end = 0x7f090014;
        public static final int expand_activities_button = 0x7f090022;
        public static final int expanded_menu = 0x7f090028;
        public static final int final_result = 0x7f090042;
        public static final int home = 0x7f090004;
        public static final int homeAsUp = 0x7f09000d;
        public static final int icon = 0x7f090026;
        public static final int ifRoom = 0x7f090018;
        public static final int image = 0x7f090023;
        public static final int listMode = 0x7f090009;
        public static final int list_item = 0x7f090025;
        public static final int middle = 0x7f090015;
        public static final int never = 0x7f090019;
        public static final int none = 0x7f09000e;
        public static final int normal = 0x7f09000a;
        public static final int progress_circular = 0x7f090005;
        public static final int progress_horizontal = 0x7f090006;
        public static final int radio = 0x7f09002b;
        public static final int search_badge = 0x7f090035;
        public static final int search_bar = 0x7f090034;
        public static final int search_button = 0x7f090036;
        public static final int search_close_btn = 0x7f09003b;
        public static final int search_edit_frame = 0x7f090037;
        public static final int search_go_btn = 0x7f09003d;
        public static final int search_mag_icon = 0x7f090038;
        public static final int search_plate = 0x7f090039;
        public static final int search_src_text = 0x7f09003a;
        public static final int search_voice_btn = 0x7f09003e;
        public static final int shortcut = 0x7f09002a;
        public static final int showCustom = 0x7f09000f;
        public static final int showHome = 0x7f090010;
        public static final int showTitle = 0x7f090011;
        public static final int spinner = 0x7f090040;
        public static final int split_action_bar = 0x7f090007;
        public static final int submit_area = 0x7f09003c;
        public static final int tabMode = 0x7f09000b;
        public static final int textView = 0x7f09003f;
        public static final int title = 0x7f090027;
        public static final int up = 0x7f090008;
        public static final int useLogo = 0x7f090012;
        public static final int withText = 0x7f09001a;
        public static final int wrap_content = 0x7f09001d;

        public id()
        {
        }
    }

    public static final class integer
    {

        public static final int abc_max_action_buttons = 0x7f0a0000;

        public integer()
        {
        }
    }

    public static final class layout
    {

        public static final int abc_action_bar_title_item = 0x7f030000;
        public static final int abc_action_bar_up_container = 0x7f030001;
        public static final int abc_action_bar_view_list_nav_layout = 0x7f030002;
        public static final int abc_action_menu_item_layout = 0x7f030003;
        public static final int abc_action_menu_layout = 0x7f030004;
        public static final int abc_action_mode_bar = 0x7f030005;
        public static final int abc_action_mode_close_item_material = 0x7f030006;
        public static final int abc_activity_chooser_view = 0x7f030007;
        public static final int abc_activity_chooser_view_include = 0x7f030008;
        public static final int abc_activity_chooser_view_list_item = 0x7f030009;
        public static final int abc_expanded_menu_layout = 0x7f03000a;
        public static final int abc_list_menu_item_checkbox = 0x7f03000b;
        public static final int abc_list_menu_item_icon = 0x7f03000c;
        public static final int abc_list_menu_item_layout = 0x7f03000d;
        public static final int abc_list_menu_item_radio = 0x7f03000e;
        public static final int abc_popup_menu_item_layout = 0x7f03000f;
        public static final int abc_screen_content_include = 0x7f030010;
        public static final int abc_screen_simple = 0x7f030011;
        public static final int abc_screen_simple_overlay_action_mode = 0x7f030012;
        public static final int abc_screen_toolbar = 0x7f030013;
        public static final int abc_search_dropdown_item_icons_2line = 0x7f030014;
        public static final int abc_search_view = 0x7f030015;
        public static final int abc_simple_dropdown_hint = 0x7f030016;
        public static final int activity_main = 0x7f030017;
        public static final int support_simple_spinner_dropdown_item = 0x7f030018;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int menu_main = 0x7f0d0000;

        public menu()
        {
        }
    }

    public static final class string
    {

        public static final int abc_action_bar_home_description = 0x7f0b0000;
        public static final int abc_action_bar_home_description_format = 0x7f0b0001;
        public static final int abc_action_bar_home_subtitle_description_format = 0x7f0b0002;
        public static final int abc_action_bar_up_description = 0x7f0b0003;
        public static final int abc_action_menu_overflow_description = 0x7f0b0004;
        public static final int abc_action_mode_done = 0x7f0b0005;
        public static final int abc_activity_chooser_view_see_all = 0x7f0b0006;
        public static final int abc_activitychooserview_choose_application = 0x7f0b0007;
        public static final int abc_searchview_description_clear = 0x7f0b0008;
        public static final int abc_searchview_description_query = 0x7f0b0009;
        public static final int abc_searchview_description_search = 0x7f0b000a;
        public static final int abc_searchview_description_submit = 0x7f0b000b;
        public static final int abc_searchview_description_voice = 0x7f0b000c;
        public static final int abc_shareactionprovider_share_with = 0x7f0b000d;
        public static final int abc_shareactionprovider_share_with_application = 0x7f0b000e;
        public static final int abc_toolbar_collapse_description = 0x7f0b000f;
        public static final int action_settings = 0x7f0b0010;
        public static final int app_name = 0x7f0b0011;
        public static final int choose_cuisine = 0x7f0b0012;
        public static final int submit_btn = 0x7f0b0013;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppTheme = 0x7f0c0000;
        public static final int Base_TextAppearance_AppCompat = 0x7f0c0001;
        public static final int Base_TextAppearance_AppCompat_Body1 = 0x7f0c0002;
        public static final int Base_TextAppearance_AppCompat_Body2 = 0x7f0c0003;
        public static final int Base_TextAppearance_AppCompat_Button = 0x7f0c0004;
        public static final int Base_TextAppearance_AppCompat_Caption = 0x7f0c0005;
        public static final int Base_TextAppearance_AppCompat_Display1 = 0x7f0c0006;
        public static final int Base_TextAppearance_AppCompat_Display2 = 0x7f0c0007;
        public static final int Base_TextAppearance_AppCompat_Display3 = 0x7f0c0008;
        public static final int Base_TextAppearance_AppCompat_Display4 = 0x7f0c0009;
        public static final int Base_TextAppearance_AppCompat_Headline = 0x7f0c000a;
        public static final int Base_TextAppearance_AppCompat_Inverse = 0x7f0c000b;
        public static final int Base_TextAppearance_AppCompat_Large = 0x7f0c000c;
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f0c000d;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0c000e;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0c000f;
        public static final int Base_TextAppearance_AppCompat_Medium = 0x7f0c0010;
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f0c0011;
        public static final int Base_TextAppearance_AppCompat_Menu = 0x7f0c0012;
        public static final int Base_TextAppearance_AppCompat_SearchResult = 0x7f0c0013;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0c0014;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f0c0015;
        public static final int Base_TextAppearance_AppCompat_Small = 0x7f0c0016;
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f0c0017;
        public static final int Base_TextAppearance_AppCompat_Subhead = 0x7f0c0018;
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f0c0019;
        public static final int Base_TextAppearance_AppCompat_Title = 0x7f0c001a;
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f0c001b;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0c001c;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0c001d;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0c001e;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f0c001f;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f0c0020;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f0c0021;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f0c0022;
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0c0023;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f0c0024;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f0c0025;
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f0c0026;
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0c0027;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f0c0028;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f0c0029;
        public static final int Base_ThemeOverlay_AppCompat = 0x7f0c0034;
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f0c0035;
        public static final int Base_ThemeOverlay_AppCompat_Dark = 0x7f0c0036;
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f0c0037;
        public static final int Base_ThemeOverlay_AppCompat_Light = 0x7f0c0038;
        public static final int Base_Theme_AppCompat = 0x7f0c002a;
        public static final int Base_Theme_AppCompat_CompactMenu = 0x7f0c002b;
        public static final int Base_Theme_AppCompat_Dialog = 0x7f0c002c;
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 0x7f0c002e;
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f0c002d;
        public static final int Base_Theme_AppCompat_Light = 0x7f0c002f;
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f0c0030;
        public static final int Base_Theme_AppCompat_Light_Dialog = 0x7f0c0031;
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f0c0033;
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f0c0032;
        public static final int Base_V11_Theme_AppCompat = 0x7f0c00e0;
        public static final int Base_V11_Theme_AppCompat_Dialog = 0x7f0c00e1;
        public static final int Base_V11_Theme_AppCompat_Light = 0x7f0c00e2;
        public static final int Base_V11_Theme_AppCompat_Light_Dialog = 0x7f0c00e3;
        public static final int Base_V14_Theme_AppCompat = 0x7f0c00e4;
        public static final int Base_V14_Theme_AppCompat_Dialog = 0x7f0c00e5;
        public static final int Base_V14_Theme_AppCompat_Light = 0x7f0c00e6;
        public static final int Base_V14_Theme_AppCompat_Light_Dialog = 0x7f0c00e7;
        public static final int Base_V21_Theme_AppCompat = 0x7f0c00e8;
        public static final int Base_V21_Theme_AppCompat_Dialog = 0x7f0c00e9;
        public static final int Base_V21_Theme_AppCompat_Light = 0x7f0c00ea;
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f0c00eb;
        public static final int Base_V7_Theme_AppCompat = 0x7f0c0039;
        public static final int Base_V7_Theme_AppCompat_Dialog = 0x7f0c003a;
        public static final int Base_V7_Theme_AppCompat_Light = 0x7f0c003b;
        public static final int Base_Widget_AppCompat_ActionBar = 0x7f0c003c;
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 0x7f0c003d;
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f0c003e;
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 0x7f0c003f;
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 0x7f0c0040;
        public static final int Base_Widget_AppCompat_ActionButton = 0x7f0c0041;
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f0c0042;
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f0c0043;
        public static final int Base_Widget_AppCompat_ActionMode = 0x7f0c0044;
        public static final int Base_Widget_AppCompat_ActivityChooserView = 0x7f0c0045;
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f0c0046;
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f0c0047;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f0c0048;
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f0c0049;
        public static final int Base_Widget_AppCompat_EditText = 0x7f0c004a;
        public static final int Base_Widget_AppCompat_Light_ActionBar = 0x7f0c004b;
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f0c004c;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0c004d;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f0c004e;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f0c004f;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f0c0050;
        public static final int Base_Widget_AppCompat_Light_ActivityChooserView = 0x7f0c0051;
        public static final int Base_Widget_AppCompat_Light_AutoCompleteTextView = 0x7f0c0052;
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 0x7f0c0053;
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f0c0054;
        public static final int Base_Widget_AppCompat_ListPopupWindow = 0x7f0c0055;
        public static final int Base_Widget_AppCompat_ListView_DropDown = 0x7f0c0056;
        public static final int Base_Widget_AppCompat_ListView_Menu = 0x7f0c0057;
        public static final int Base_Widget_AppCompat_PopupMenu = 0x7f0c0058;
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f0c0059;
        public static final int Base_Widget_AppCompat_PopupWindow = 0x7f0c005a;
        public static final int Base_Widget_AppCompat_ProgressBar = 0x7f0c005b;
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 0x7f0c005c;
        public static final int Base_Widget_AppCompat_SearchView = 0x7f0c005d;
        public static final int Base_Widget_AppCompat_Spinner = 0x7f0c005e;
        public static final int Base_Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f0c005f;
        public static final int Base_Widget_AppCompat_Toolbar = 0x7f0c0060;
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f0c0061;
        public static final int Platform_AppCompat = 0x7f0c0062;
        public static final int Platform_AppCompat_Dialog = 0x7f0c0063;
        public static final int Platform_AppCompat_Light = 0x7f0c0064;
        public static final int Platform_AppCompat_Light_Dialog = 0x7f0c0065;
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f0c0066;
        public static final int RtlOverlay_Widget_AppCompat_ActionButton_CloseMode = 0x7f0c0067;
        public static final int RtlOverlay_Widget_AppCompat_ActionButton_Overflow = 0x7f0c0068;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f0c0069;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f0c006a;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f0c006b;
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f0c0071;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f0c006c;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f0c006d;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f0c006e;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f0c006f;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f0c0070;
        public static final int TextAppearance_AppCompat = 0x7f0c0072;
        public static final int TextAppearance_AppCompat_Body1 = 0x7f0c0073;
        public static final int TextAppearance_AppCompat_Body2 = 0x7f0c0074;
        public static final int TextAppearance_AppCompat_Button = 0x7f0c0075;
        public static final int TextAppearance_AppCompat_Caption = 0x7f0c0076;
        public static final int TextAppearance_AppCompat_Display1 = 0x7f0c0077;
        public static final int TextAppearance_AppCompat_Display2 = 0x7f0c0078;
        public static final int TextAppearance_AppCompat_Display3 = 0x7f0c0079;
        public static final int TextAppearance_AppCompat_Display4 = 0x7f0c007a;
        public static final int TextAppearance_AppCompat_Headline = 0x7f0c007b;
        public static final int TextAppearance_AppCompat_Inverse = 0x7f0c007c;
        public static final int TextAppearance_AppCompat_Large = 0x7f0c007d;
        public static final int TextAppearance_AppCompat_Large_Inverse = 0x7f0c007e;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f0c007f;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f0c0080;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0c0081;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0c0082;
        public static final int TextAppearance_AppCompat_Medium = 0x7f0c0083;
        public static final int TextAppearance_AppCompat_Medium_Inverse = 0x7f0c0084;
        public static final int TextAppearance_AppCompat_Menu = 0x7f0c0085;
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0c0086;
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f0c0087;
        public static final int TextAppearance_AppCompat_Small = 0x7f0c0088;
        public static final int TextAppearance_AppCompat_Small_Inverse = 0x7f0c0089;
        public static final int TextAppearance_AppCompat_Subhead = 0x7f0c008a;
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 0x7f0c008b;
        public static final int TextAppearance_AppCompat_Title = 0x7f0c008c;
        public static final int TextAppearance_AppCompat_Title_Inverse = 0x7f0c008d;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0c008e;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0c008f;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0c0090;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f0c0091;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f0c0092;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f0c0093;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f0c0094;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f0c0095;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f0c0096;
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0c0097;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f0c0098;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f0c0099;
        public static final int TextAppearance_AppCompat_Widget_Switch = 0x7f0c009a;
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0c009b;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f0c009c;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f0c009d;
        public static final int ThemeOverlay_AppCompat = 0x7f0c00a8;
        public static final int ThemeOverlay_AppCompat_ActionBar = 0x7f0c00a9;
        public static final int ThemeOverlay_AppCompat_Dark = 0x7f0c00aa;
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f0c00ab;
        public static final int ThemeOverlay_AppCompat_Light = 0x7f0c00ac;
        public static final int Theme_AppCompat = 0x7f0c009e;
        public static final int Theme_AppCompat_CompactMenu = 0x7f0c009f;
        public static final int Theme_AppCompat_Dialog = 0x7f0c00a0;
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f0c00a1;
        public static final int Theme_AppCompat_Light = 0x7f0c00a2;
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f0c00a3;
        public static final int Theme_AppCompat_Light_Dialog = 0x7f0c00a4;
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f0c00a5;
        public static final int Theme_AppCompat_Light_NoActionBar = 0x7f0c00a6;
        public static final int Theme_AppCompat_NoActionBar = 0x7f0c00a7;
        public static final int Widget_AppCompat_ActionBar = 0x7f0c00ad;
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f0c00ae;
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f0c00af;
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f0c00b0;
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f0c00b1;
        public static final int Widget_AppCompat_ActionButton = 0x7f0c00b2;
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f0c00b3;
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f0c00b4;
        public static final int Widget_AppCompat_ActionMode = 0x7f0c00b5;
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f0c00b6;
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f0c00b7;
        public static final int Widget_AppCompat_CompoundButton_Switch = 0x7f0c00b8;
        public static final int Widget_AppCompat_DrawerArrowToggle = 0x7f0c00b9;
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f0c00ba;
        public static final int Widget_AppCompat_EditText = 0x7f0c00bb;
        public static final int Widget_AppCompat_Light_ActionBar = 0x7f0c00bc;
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f0c00bd;
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f0c00be;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0c00bf;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f0c00c0;
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f0c00c1;
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f0c00c2;
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f0c00c3;
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f0c00c4;
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f0c00c5;
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f0c00c6;
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f0c00c7;
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f0c00c8;
        public static final int Widget_AppCompat_Light_ActivityChooserView = 0x7f0c00c9;
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f0c00ca;
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f0c00cb;
        public static final int Widget_AppCompat_Light_ListPopupWindow = 0x7f0c00cc;
        public static final int Widget_AppCompat_Light_ListView_DropDown = 0x7f0c00cd;
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f0c00ce;
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f0c00cf;
        public static final int Widget_AppCompat_Light_SearchView = 0x7f0c00d0;
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f0c00d1;
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f0c00d2;
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f0c00d3;
        public static final int Widget_AppCompat_ListView_Menu = 0x7f0c00d4;
        public static final int Widget_AppCompat_PopupMenu = 0x7f0c00d5;
        public static final int Widget_AppCompat_PopupMenu_Overflow = 0x7f0c00d6;
        public static final int Widget_AppCompat_PopupWindow = 0x7f0c00d7;
        public static final int Widget_AppCompat_ProgressBar = 0x7f0c00d8;
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 0x7f0c00d9;
        public static final int Widget_AppCompat_SearchView = 0x7f0c00da;
        public static final int Widget_AppCompat_Spinner = 0x7f0c00db;
        public static final int Widget_AppCompat_Spinner_DropDown = 0x7f0c00dc;
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f0c00dd;
        public static final int Widget_AppCompat_Toolbar = 0x7f0c00de;
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f0c00df;

        public style()
        {
        }
    }

    public static final class styleable
    {

        public static final int ActionBar[] = {
            0x7f010001, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 
            0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 
            0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f010071
        };
        public static final int ActionBarLayout[] = {
            0x10100b3
        };
        public static final int ActionBarLayout_android_layout_gravity = 0;
        public static final int ActionBar_background = 10;
        public static final int ActionBar_backgroundSplit = 12;
        public static final int ActionBar_backgroundStacked = 11;
        public static final int ActionBar_contentInsetEnd = 21;
        public static final int ActionBar_contentInsetLeft = 22;
        public static final int ActionBar_contentInsetRight = 23;
        public static final int ActionBar_contentInsetStart = 20;
        public static final int ActionBar_customNavigationLayout = 13;
        public static final int ActionBar_displayOptions = 3;
        public static final int ActionBar_divider = 9;
        public static final int ActionBar_elevation = 24;
        public static final int ActionBar_height = 0;
        public static final int ActionBar_hideOnContentScroll = 19;
        public static final int ActionBar_homeAsUpIndicator = 26;
        public static final int ActionBar_homeLayout = 14;
        public static final int ActionBar_icon = 7;
        public static final int ActionBar_indeterminateProgressStyle = 16;
        public static final int ActionBar_itemPadding = 18;
        public static final int ActionBar_logo = 8;
        public static final int ActionBar_navigationMode = 2;
        public static final int ActionBar_popupTheme = 25;
        public static final int ActionBar_progressBarPadding = 17;
        public static final int ActionBar_progressBarStyle = 15;
        public static final int ActionBar_subtitle = 4;
        public static final int ActionBar_subtitleTextStyle = 6;
        public static final int ActionBar_title = 1;
        public static final int ActionBar_titleTextStyle = 5;
        public static final int ActionMenuItemView[] = {
            0x101013f
        };
        public static final int ActionMenuItemView_android_minWidth = 0;
        public static final int ActionMenuView[] = new int[0];
        public static final int ActionMode[] = {
            0x7f010001, 0x7f010007, 0x7f010008, 0x7f01000c, 0x7f01000e, 0x7f01001c
        };
        public static final int ActionMode_background = 3;
        public static final int ActionMode_backgroundSplit = 4;
        public static final int ActionMode_closeItemLayout = 5;
        public static final int ActionMode_height = 0;
        public static final int ActionMode_subtitleTextStyle = 2;
        public static final int ActionMode_titleTextStyle = 1;
        public static final int ActivityChooserView[] = {
            0x7f01001d, 0x7f01001e
        };
        public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
        public static final int ActivityChooserView_initialActivityCount = 0;
        public static final int CompatTextView[] = {
            0x7f01001f
        };
        public static final int CompatTextView_textAllCaps = 0;
        public static final int DrawerArrowToggle[] = {
            0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023, 0x7f010024, 0x7f010025, 0x7f010026, 0x7f010027
        };
        public static final int DrawerArrowToggle_barSize = 6;
        public static final int DrawerArrowToggle_color = 0;
        public static final int DrawerArrowToggle_drawableSize = 2;
        public static final int DrawerArrowToggle_gapBetweenBars = 3;
        public static final int DrawerArrowToggle_middleBarArrowSize = 5;
        public static final int DrawerArrowToggle_spinBars = 1;
        public static final int DrawerArrowToggle_thickness = 7;
        public static final int DrawerArrowToggle_topBottomBarArrowSize = 4;
        public static final int LinearLayoutCompat[] = {
            0x10100af, 0x10100c4, 0x1010126, 0x1010127, 0x1010128, 0x7f01000b, 0x7f010028, 0x7f010029, 0x7f01002a
        };
        public static final int LinearLayoutCompat_Layout[] = {
            0x10100b3, 0x10100f4, 0x10100f5, 0x1010181
        };
        public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
        public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
        public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
        public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
        public static final int LinearLayoutCompat_android_baselineAligned = 2;
        public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
        public static final int LinearLayoutCompat_android_gravity = 0;
        public static final int LinearLayoutCompat_android_orientation = 1;
        public static final int LinearLayoutCompat_android_weightSum = 4;
        public static final int LinearLayoutCompat_divider = 5;
        public static final int LinearLayoutCompat_dividerPadding = 8;
        public static final int LinearLayoutCompat_measureWithLargestChild = 6;
        public static final int LinearLayoutCompat_showDividers = 7;
        public static final int ListPopupWindow[] = {
            0x10102ac, 0x10102ad
        };
        public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
        public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
        public static final int MenuGroup[] = {
            0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
        };
        public static final int MenuGroup_android_checkableBehavior = 5;
        public static final int MenuGroup_android_enabled = 0;
        public static final int MenuGroup_android_id = 1;
        public static final int MenuGroup_android_menuCategory = 3;
        public static final int MenuGroup_android_orderInCategory = 4;
        public static final int MenuGroup_android_visible = 2;
        public static final int MenuItem[] = {
            0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
            0x10101e4, 0x10101e5, 0x101026f, 0x7f01002b, 0x7f01002c, 0x7f01002d, 0x7f01002e
        };
        public static final int MenuItem_actionLayout = 14;
        public static final int MenuItem_actionProviderClass = 16;
        public static final int MenuItem_actionViewClass = 15;
        public static final int MenuItem_android_alphabeticShortcut = 9;
        public static final int MenuItem_android_checkable = 11;
        public static final int MenuItem_android_checked = 3;
        public static final int MenuItem_android_enabled = 1;
        public static final int MenuItem_android_icon = 0;
        public static final int MenuItem_android_id = 2;
        public static final int MenuItem_android_menuCategory = 5;
        public static final int MenuItem_android_numericShortcut = 10;
        public static final int MenuItem_android_onClick = 12;
        public static final int MenuItem_android_orderInCategory = 6;
        public static final int MenuItem_android_title = 7;
        public static final int MenuItem_android_titleCondensed = 8;
        public static final int MenuItem_android_visible = 4;
        public static final int MenuItem_showAsAction = 13;
        public static final int MenuView[] = {
            0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x7f01002f
        };
        public static final int MenuView_android_headerBackground = 4;
        public static final int MenuView_android_horizontalDivider = 2;
        public static final int MenuView_android_itemBackground = 5;
        public static final int MenuView_android_itemIconDisabledAlpha = 6;
        public static final int MenuView_android_itemTextAppearance = 1;
        public static final int MenuView_android_verticalDivider = 3;
        public static final int MenuView_android_windowAnimationStyle = 0;
        public static final int MenuView_preserveIconSpacing = 7;
        public static final int PopupWindow[] = {
            0x1010176, 0x7f010030
        };
        public static final int PopupWindowBackgroundState[] = {
            0x7f010031
        };
        public static final int PopupWindowBackgroundState_state_above_anchor = 0;
        public static final int PopupWindow_android_popupBackground = 0;
        public static final int PopupWindow_overlapAnchor = 1;
        public static final int SearchView[] = {
            0x10100da, 0x101011f, 0x1010220, 0x1010264, 0x7f010032, 0x7f010033, 0x7f010034, 0x7f010035, 0x7f010036, 0x7f010037, 
            0x7f010038, 0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c
        };
        public static final int SearchView_android_focusable = 0;
        public static final int SearchView_android_imeOptions = 3;
        public static final int SearchView_android_inputType = 2;
        public static final int SearchView_android_maxWidth = 1;
        public static final int SearchView_closeIcon = 7;
        public static final int SearchView_commitIcon = 11;
        public static final int SearchView_goIcon = 8;
        public static final int SearchView_iconifiedByDefault = 5;
        public static final int SearchView_layout = 4;
        public static final int SearchView_queryBackground = 13;
        public static final int SearchView_queryHint = 6;
        public static final int SearchView_searchIcon = 9;
        public static final int SearchView_submitBackground = 14;
        public static final int SearchView_suggestionRowLayout = 12;
        public static final int SearchView_voiceIcon = 10;
        public static final int Spinner[] = {
            0x10100af, 0x10100d4, 0x1010175, 0x1010176, 0x1010262, 0x10102ac, 0x10102ad, 0x7f01003d, 0x7f01003e, 0x7f01003f, 
            0x7f010040
        };
        public static final int Spinner_android_background = 1;
        public static final int Spinner_android_dropDownHorizontalOffset = 5;
        public static final int Spinner_android_dropDownSelector = 2;
        public static final int Spinner_android_dropDownVerticalOffset = 6;
        public static final int Spinner_android_dropDownWidth = 4;
        public static final int Spinner_android_gravity = 0;
        public static final int Spinner_android_popupBackground = 3;
        public static final int Spinner_disableChildrenWhenDisabled = 10;
        public static final int Spinner_popupPromptView = 9;
        public static final int Spinner_prompt = 7;
        public static final int Spinner_spinnerMode = 8;
        public static final int SwitchCompat[] = {
            0x1010124, 0x1010125, 0x1010142, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 0x7f010047
        };
        public static final int SwitchCompat_android_textOff = 1;
        public static final int SwitchCompat_android_textOn = 0;
        public static final int SwitchCompat_android_thumb = 2;
        public static final int SwitchCompat_showText = 9;
        public static final int SwitchCompat_splitTrack = 8;
        public static final int SwitchCompat_switchMinWidth = 6;
        public static final int SwitchCompat_switchPadding = 7;
        public static final int SwitchCompat_switchTextAppearance = 5;
        public static final int SwitchCompat_thumbTextPadding = 4;
        public static final int SwitchCompat_track = 3;
        public static final int Theme[] = {
            0x1010057, 0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c, 0x7f01004d, 0x7f01004e, 0x7f01004f, 0x7f010050, 
            0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054, 0x7f010055, 0x7f010056, 0x7f010057, 0x7f010058, 0x7f010059, 0x7f01005a, 
            0x7f01005b, 0x7f01005c, 0x7f01005d, 0x7f01005e, 0x7f01005f, 0x7f010060, 0x7f010061, 0x7f010062, 0x7f010063, 0x7f010064, 
            0x7f010065, 0x7f010066, 0x7f010067, 0x7f010068, 0x7f010069, 0x7f01006a, 0x7f01006b, 0x7f01006c, 0x7f01006d, 0x7f01006e, 
            0x7f01006f, 0x7f010070, 0x7f010071, 0x7f010072, 0x7f010073, 0x7f010074, 0x7f010075, 0x7f010076, 0x7f010077, 0x7f010078, 
            0x7f010079, 0x7f01007a, 0x7f01007b, 0x7f01007c, 0x7f01007d, 0x7f01007e, 0x7f01007f, 0x7f010080, 0x7f010081, 0x7f010082, 
            0x7f010083, 0x7f010084, 0x7f010085, 0x7f010086, 0x7f010087, 0x7f010088, 0x7f010089, 0x7f01008a, 0x7f01008b, 0x7f01008c, 
            0x7f01008d, 0x7f01008e, 0x7f01008f, 0x7f010090, 0x7f010091, 0x7f010092, 0x7f010093, 0x7f010094, 0x7f010095, 0x7f010096, 
            0x7f010097, 0x7f010098, 0x7f010099
        };
        public static final int Theme_actionBarDivider = 19;
        public static final int Theme_actionBarItemBackground = 20;
        public static final int Theme_actionBarPopupTheme = 13;
        public static final int Theme_actionBarSize = 18;
        public static final int Theme_actionBarSplitStyle = 15;
        public static final int Theme_actionBarStyle = 14;
        public static final int Theme_actionBarTabBarStyle = 9;
        public static final int Theme_actionBarTabStyle = 8;
        public static final int Theme_actionBarTabTextStyle = 10;
        public static final int Theme_actionBarTheme = 16;
        public static final int Theme_actionBarWidgetTheme = 17;
        public static final int Theme_actionButtonStyle = 43;
        public static final int Theme_actionDropDownStyle = 38;
        public static final int Theme_actionMenuTextAppearance = 21;
        public static final int Theme_actionMenuTextColor = 22;
        public static final int Theme_actionModeBackground = 25;
        public static final int Theme_actionModeCloseButtonStyle = 24;
        public static final int Theme_actionModeCloseDrawable = 27;
        public static final int Theme_actionModeCopyDrawable = 29;
        public static final int Theme_actionModeCutDrawable = 28;
        public static final int Theme_actionModeFindDrawable = 33;
        public static final int Theme_actionModePasteDrawable = 30;
        public static final int Theme_actionModePopupWindowStyle = 35;
        public static final int Theme_actionModeSelectAllDrawable = 31;
        public static final int Theme_actionModeShareDrawable = 32;
        public static final int Theme_actionModeSplitBackground = 26;
        public static final int Theme_actionModeStyle = 23;
        public static final int Theme_actionModeWebSearchDrawable = 34;
        public static final int Theme_actionOverflowButtonStyle = 11;
        public static final int Theme_actionOverflowMenuStyle = 12;
        public static final int Theme_activityChooserViewStyle = 50;
        public static final int Theme_android_windowIsFloating = 0;
        public static final int Theme_buttonBarButtonStyle = 45;
        public static final int Theme_buttonBarStyle = 44;
        public static final int Theme_colorAccent = 77;
        public static final int Theme_colorButtonNormal = 81;
        public static final int Theme_colorControlActivated = 79;
        public static final int Theme_colorControlHighlight = 80;
        public static final int Theme_colorControlNormal = 78;
        public static final int Theme_colorPrimary = 75;
        public static final int Theme_colorPrimaryDark = 76;
        public static final int Theme_colorSwitchThumbNormal = 82;
        public static final int Theme_dividerHorizontal = 49;
        public static final int Theme_dividerVertical = 48;
        public static final int Theme_dropDownListViewStyle = 67;
        public static final int Theme_dropdownListPreferredItemHeight = 39;
        public static final int Theme_editTextBackground = 56;
        public static final int Theme_editTextColor = 55;
        public static final int Theme_homeAsUpIndicator = 42;
        public static final int Theme_listChoiceBackgroundIndicator = 74;
        public static final int Theme_listPopupWindowStyle = 68;
        public static final int Theme_listPreferredItemHeight = 62;
        public static final int Theme_listPreferredItemHeightLarge = 64;
        public static final int Theme_listPreferredItemHeightSmall = 63;
        public static final int Theme_listPreferredItemPaddingLeft = 65;
        public static final int Theme_listPreferredItemPaddingRight = 66;
        public static final int Theme_panelBackground = 71;
        public static final int Theme_panelMenuListTheme = 73;
        public static final int Theme_panelMenuListWidth = 72;
        public static final int Theme_popupMenuStyle = 53;
        public static final int Theme_popupWindowStyle = 54;
        public static final int Theme_searchViewStyle = 61;
        public static final int Theme_selectableItemBackground = 46;
        public static final int Theme_selectableItemBackgroundBorderless = 47;
        public static final int Theme_spinnerDropDownItemStyle = 41;
        public static final int Theme_spinnerStyle = 40;
        public static final int Theme_switchStyle = 57;
        public static final int Theme_textAppearanceLargePopupMenu = 36;
        public static final int Theme_textAppearanceListItem = 69;
        public static final int Theme_textAppearanceListItemSmall = 70;
        public static final int Theme_textAppearanceSearchResultSubtitle = 59;
        public static final int Theme_textAppearanceSearchResultTitle = 58;
        public static final int Theme_textAppearanceSmallPopupMenu = 37;
        public static final int Theme_textColorSearchUrl = 60;
        public static final int Theme_toolbarNavigationButtonStyle = 52;
        public static final int Theme_toolbarStyle = 51;
        public static final int Theme_windowActionBar = 1;
        public static final int Theme_windowActionBarOverlay = 2;
        public static final int Theme_windowActionModeOverlay = 3;
        public static final int Theme_windowFixedHeightMajor = 7;
        public static final int Theme_windowFixedHeightMinor = 5;
        public static final int Theme_windowFixedWidthMajor = 4;
        public static final int Theme_windowFixedWidthMinor = 6;
        public static final int Toolbar[] = {
            0x10100af, 0x1010140, 0x7f010003, 0x7f010006, 0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001b, 0x7f01009a, 
            0x7f01009b, 0x7f01009c, 0x7f01009d, 0x7f01009e, 0x7f01009f, 0x7f0100a0, 0x7f0100a1, 0x7f0100a2, 0x7f0100a3, 0x7f0100a4, 
            0x7f0100a5, 0x7f0100a6
        };
        public static final int Toolbar_android_gravity = 0;
        public static final int Toolbar_android_minHeight = 1;
        public static final int Toolbar_collapseContentDescription = 19;
        public static final int Toolbar_collapseIcon = 18;
        public static final int Toolbar_contentInsetEnd = 5;
        public static final int Toolbar_contentInsetLeft = 6;
        public static final int Toolbar_contentInsetRight = 7;
        public static final int Toolbar_contentInsetStart = 4;
        public static final int Toolbar_maxButtonHeight = 16;
        public static final int Toolbar_navigationContentDescription = 21;
        public static final int Toolbar_navigationIcon = 20;
        public static final int Toolbar_popupTheme = 8;
        public static final int Toolbar_subtitle = 3;
        public static final int Toolbar_subtitleTextAppearance = 10;
        public static final int Toolbar_theme = 17;
        public static final int Toolbar_title = 2;
        public static final int Toolbar_titleMarginBottom = 15;
        public static final int Toolbar_titleMarginEnd = 13;
        public static final int Toolbar_titleMarginStart = 12;
        public static final int Toolbar_titleMarginTop = 14;
        public static final int Toolbar_titleMargins = 11;
        public static final int Toolbar_titleTextAppearance = 9;
        public static final int View[] = {
            0x10100da, 0x7f0100a7, 0x7f0100a8
        };
        public static final int ViewStubCompat[] = {
            0x10100d0, 0x10100f2, 0x10100f3
        };
        public static final int ViewStubCompat_android_id = 0;
        public static final int ViewStubCompat_android_inflatedId = 2;
        public static final int ViewStubCompat_android_layout = 1;
        public static final int View_android_focusable = 0;
        public static final int View_paddingEnd = 2;
        public static final int View_paddingStart = 1;


        public styleable()
        {
        }
    }


    public R()
    {
    }
}
