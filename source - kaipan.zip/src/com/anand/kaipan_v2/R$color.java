// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


// Referenced classes of package com.anand.kaipan_v2:
//            R

public static final class 
{

    public static final int abc_background_cache_hint_selector_material_dark = 0x7f070031;
    public static final int abc_background_cache_hint_selector_material_light = 0x7f070032;
    public static final int abc_input_method_navigation_guard = 0x7f070000;
    public static final int abc_primary_text_disable_only_material_dark = 0x7f070033;
    public static final int abc_primary_text_disable_only_material_light = 0x7f070034;
    public static final int abc_primary_text_material_dark = 0x7f070035;
    public static final int abc_primary_text_material_light = 0x7f070036;
    public static final int abc_search_url_text = 0x7f070037;
    public static final int abc_search_url_text_normal = 0x7f070001;
    public static final int abc_search_url_text_pressed = 0x7f070002;
    public static final int abc_search_url_text_selected = 0x7f070003;
    public static final int abc_secondary_text_material_dark = 0x7f070038;
    public static final int abc_secondary_text_material_light = 0x7f070039;
    public static final int accent_material_dark = 0x7f070004;
    public static final int accent_material_light = 0x7f070005;
    public static final int background_floating_material_dark = 0x7f070006;
    public static final int background_floating_material_light = 0x7f070007;
    public static final int background_material_dark = 0x7f070008;
    public static final int background_material_light = 0x7f070009;
    public static final int bright_foreground_disabled_material_dark = 0x7f07000a;
    public static final int bright_foreground_disabled_material_light = 0x7f07000b;
    public static final int bright_foreground_inverse_material_dark = 0x7f07000c;
    public static final int bright_foreground_inverse_material_light = 0x7f07000d;
    public static final int bright_foreground_material_dark = 0x7f07000e;
    public static final int bright_foreground_material_light = 0x7f07000f;
    public static final int button_material_dark = 0x7f070010;
    public static final int button_material_light = 0x7f070011;
    public static final int dim_foreground_disabled_material_dark = 0x7f070012;
    public static final int dim_foreground_disabled_material_light = 0x7f070013;
    public static final int dim_foreground_material_dark = 0x7f070014;
    public static final int dim_foreground_material_light = 0x7f070015;
    public static final int highlighted_text_material_dark = 0x7f070016;
    public static final int highlighted_text_material_light = 0x7f070017;
    public static final int hint_foreground_material_dark = 0x7f070018;
    public static final int hint_foreground_material_light = 0x7f070019;
    public static final int link_text_material_dark = 0x7f07001a;
    public static final int link_text_material_light = 0x7f07001b;
    public static final int material_blue_grey_800 = 0x7f07001c;
    public static final int material_blue_grey_900 = 0x7f07001d;
    public static final int material_blue_grey_950 = 0x7f07001e;
    public static final int material_deep_teal_200 = 0x7f07001f;
    public static final int material_deep_teal_500 = 0x7f070020;
    public static final int primary_dark_material_dark = 0x7f070021;
    public static final int primary_dark_material_light = 0x7f070022;
    public static final int primary_material_dark = 0x7f070023;
    public static final int primary_material_light = 0x7f070024;
    public static final int primary_text_default_material_dark = 0x7f070025;
    public static final int primary_text_default_material_light = 0x7f070026;
    public static final int primary_text_disabled_material_dark = 0x7f070027;
    public static final int primary_text_disabled_material_light = 0x7f070028;
    public static final int ripple_material_dark = 0x7f070029;
    public static final int ripple_material_light = 0x7f07002a;
    public static final int secondary_text_default_material_dark = 0x7f07002b;
    public static final int secondary_text_default_material_light = 0x7f07002c;
    public static final int secondary_text_disabled_material_dark = 0x7f07002d;
    public static final int secondary_text_disabled_material_light = 0x7f07002e;
    public static final int switch_thumb_normal_material_dark = 0x7f07002f;
    public static final int switch_thumb_normal_material_light = 0x7f070030;

    public ()
    {
    }
}
