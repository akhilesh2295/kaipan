// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends ActionBarActivity
{

    public static String table_search_name;
    String ans;
    List maharashtrian;
    int max;
    List rajasthani;
    int randomNum;
    List south_indian;

    public MainActivity()
    {
        max = 0;
        randomNum = 0;
        maharashtrian = Arrays.asList(new String[] {
            "Poha", "Upma", "Vada Pav", "Pav Bhaji", "Misal Pav", "Aamti Bhaat", "Kothimbir Vadi", "Batata Vada", "Zunka Bhakri", "Pooran Poli"
        });
        rajasthani = Arrays.asList(new String[] {
            "Gatte ki Sabzi", "Aamras ki kadhi", "Ghewar", "Mirchi vada", "Dal Bati", "Mawa Kachori", "Malpova (sweet)", "Ker Sangri", "Papad ki subzee", "Rajasthani Chane"
        });
        south_indian = Arrays.asList(new String[] {
            "Idli", "Dosa", "Uthappa", "Appam", "Avial", "Bread Upma", "Adai", "Butter Milk Rassam", "Poriyal", "Payasam"
        });
    }

    public String change_input_to_table_name(String s)
    {
        String s1 = "all";
        if (s.equals("Maharashtrian"))
        {
            s1 = "maharashtrian";
            max = maharashtrian.size();
        }
        if (s.equals("Rajasthani"))
        {
            s1 = "rajasthani";
            max = rajasthani.size();
        }
        if (s.equals("South-Indian"))
        {
            s1 = "south_indian";
            max = south_indian.size();
        }
        if (s.equals("Chinese"))
        {
            s1 = "chinese";
        }
        if (s.equals("Lebanese"))
        {
            s1 = "lebanese";
        }
        return s1;
    }

    public void give_ans(String s)
    {
        byte byte0 = -1;
        s.hashCode();
        JVM INSTR lookupswitch 3: default 40
    //                   -806605445: 83
    //                   1662911975: 69
    //                   1725825225: 97;
           goto _L1 _L2 _L3 _L4
_L1:
        break; /* Loop/switch isn't completed */
_L4:
        break MISSING_BLOCK_LABEL_97;
_L5:
        switch (byte0)
        {
        default:
            return;

        case 0: // '\0'
            ans = (String)maharashtrian.get(randomNum);
            return;

        case 1: // '\001'
            ans = (String)rajasthani.get(randomNum);
            return;

        case 2: // '\002'
            ans = (String)south_indian.get(randomNum);
            break;
        }
        break MISSING_BLOCK_LABEL_173;
_L3:
        if (s.equals("maharashtrian"))
        {
            byte0 = 0;
        }
          goto _L5
_L2:
        if (s.equals("rajasthani"))
        {
            byte0 = 1;
        }
          goto _L5
        if (s.equals("south_indian"))
        {
            byte0 = 2;
        }
          goto _L5
    }

    public void kai_pan(View view)
    {
        table_search_name = change_input_to_table_name(((Spinner)findViewById(0x7f090040)).getSelectedItem().toString());
        Toast.makeText(getBaseContext(), table_search_name, 0).show();
        randomNum = (new Random()).nextInt(max);
        give_ans(table_search_name);
        ((TextView)findViewById(0x7f090042)).setText(ans);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030017);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(0x7f0d0000, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        if (menuitem.getItemId() == 0x7f090043)
        {
            return true;
        } else
        {
            return super.onOptionsItemSelected(menuitem);
        }
    }
}
