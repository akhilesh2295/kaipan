// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


// Referenced classes of package com.anand.kaipan_v2:
//            R

public static final class 
{

    public static final int abc_action_bar_embed_tabs = 0x7f060000;
    public static final int abc_action_bar_embed_tabs_pre_jb = 0x7f060001;
    public static final int abc_action_bar_expanded_action_views_exclusive = 0x7f060002;
    public static final int abc_config_actionMenuItemAllCaps = 0x7f060003;
    public static final int abc_config_allowActionMenuItemTextWithIcon = 0x7f060004;
    public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 0x7f060005;

    public ()
    {
    }
}
