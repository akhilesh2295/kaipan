// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


// Referenced classes of package com.anand.kaipan_v2:
//            R

public static final class 
{

    public static final int ActionBar[] = {
        0x7f010001, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 
        0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 
        0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f010071
    };
    public static final int ActionBarLayout[] = {
        0x10100b3
    };
    public static final int ActionBarLayout_android_layout_gravity = 0;
    public static final int ActionBar_background = 10;
    public static final int ActionBar_backgroundSplit = 12;
    public static final int ActionBar_backgroundStacked = 11;
    public static final int ActionBar_contentInsetEnd = 21;
    public static final int ActionBar_contentInsetLeft = 22;
    public static final int ActionBar_contentInsetRight = 23;
    public static final int ActionBar_contentInsetStart = 20;
    public static final int ActionBar_customNavigationLayout = 13;
    public static final int ActionBar_displayOptions = 3;
    public static final int ActionBar_divider = 9;
    public static final int ActionBar_elevation = 24;
    public static final int ActionBar_height = 0;
    public static final int ActionBar_hideOnContentScroll = 19;
    public static final int ActionBar_homeAsUpIndicator = 26;
    public static final int ActionBar_homeLayout = 14;
    public static final int ActionBar_icon = 7;
    public static final int ActionBar_indeterminateProgressStyle = 16;
    public static final int ActionBar_itemPadding = 18;
    public static final int ActionBar_logo = 8;
    public static final int ActionBar_navigationMode = 2;
    public static final int ActionBar_popupTheme = 25;
    public static final int ActionBar_progressBarPadding = 17;
    public static final int ActionBar_progressBarStyle = 15;
    public static final int ActionBar_subtitle = 4;
    public static final int ActionBar_subtitleTextStyle = 6;
    public static final int ActionBar_title = 1;
    public static final int ActionBar_titleTextStyle = 5;
    public static final int ActionMenuItemView[] = {
        0x101013f
    };
    public static final int ActionMenuItemView_android_minWidth = 0;
    public static final int ActionMenuView[] = new int[0];
    public static final int ActionMode[] = {
        0x7f010001, 0x7f010007, 0x7f010008, 0x7f01000c, 0x7f01000e, 0x7f01001c
    };
    public static final int ActionMode_background = 3;
    public static final int ActionMode_backgroundSplit = 4;
    public static final int ActionMode_closeItemLayout = 5;
    public static final int ActionMode_height = 0;
    public static final int ActionMode_subtitleTextStyle = 2;
    public static final int ActionMode_titleTextStyle = 1;
    public static final int ActivityChooserView[] = {
        0x7f01001d, 0x7f01001e
    };
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
    public static final int ActivityChooserView_initialActivityCount = 0;
    public static final int CompatTextView[] = {
        0x7f01001f
    };
    public static final int CompatTextView_textAllCaps = 0;
    public static final int DrawerArrowToggle[] = {
        0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023, 0x7f010024, 0x7f010025, 0x7f010026, 0x7f010027
    };
    public static final int DrawerArrowToggle_barSize = 6;
    public static final int DrawerArrowToggle_color = 0;
    public static final int DrawerArrowToggle_drawableSize = 2;
    public static final int DrawerArrowToggle_gapBetweenBars = 3;
    public static final int DrawerArrowToggle_middleBarArrowSize = 5;
    public static final int DrawerArrowToggle_spinBars = 1;
    public static final int DrawerArrowToggle_thickness = 7;
    public static final int DrawerArrowToggle_topBottomBarArrowSize = 4;
    public static final int LinearLayoutCompat[] = {
        0x10100af, 0x10100c4, 0x1010126, 0x1010127, 0x1010128, 0x7f01000b, 0x7f010028, 0x7f010029, 0x7f01002a
    };
    public static final int LinearLayoutCompat_Layout[] = {
        0x10100b3, 0x10100f4, 0x10100f5, 0x1010181
    };
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    public static final int LinearLayoutCompat_android_gravity = 0;
    public static final int LinearLayoutCompat_android_orientation = 1;
    public static final int LinearLayoutCompat_android_weightSum = 4;
    public static final int LinearLayoutCompat_divider = 5;
    public static final int LinearLayoutCompat_dividerPadding = 8;
    public static final int LinearLayoutCompat_measureWithLargestChild = 6;
    public static final int LinearLayoutCompat_showDividers = 7;
    public static final int ListPopupWindow[] = {
        0x10102ac, 0x10102ad
    };
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    public static final int MenuGroup[] = {
        0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
    };
    public static final int MenuGroup_android_checkableBehavior = 5;
    public static final int MenuGroup_android_enabled = 0;
    public static final int MenuGroup_android_id = 1;
    public static final int MenuGroup_android_menuCategory = 3;
    public static final int MenuGroup_android_orderInCategory = 4;
    public static final int MenuGroup_android_visible = 2;
    public static final int MenuItem[] = {
        0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
        0x10101e4, 0x10101e5, 0x101026f, 0x7f01002b, 0x7f01002c, 0x7f01002d, 0x7f01002e
    };
    public static final int MenuItem_actionLayout = 14;
    public static final int MenuItem_actionProviderClass = 16;
    public static final int MenuItem_actionViewClass = 15;
    public static final int MenuItem_android_alphabeticShortcut = 9;
    public static final int MenuItem_android_checkable = 11;
    public static final int MenuItem_android_checked = 3;
    public static final int MenuItem_android_enabled = 1;
    public static final int MenuItem_android_icon = 0;
    public static final int MenuItem_android_id = 2;
    public static final int MenuItem_android_menuCategory = 5;
    public static final int MenuItem_android_numericShortcut = 10;
    public static final int MenuItem_android_onClick = 12;
    public static final int MenuItem_android_orderInCategory = 6;
    public static final int MenuItem_android_title = 7;
    public static final int MenuItem_android_titleCondensed = 8;
    public static final int MenuItem_android_visible = 4;
    public static final int MenuItem_showAsAction = 13;
    public static final int MenuView[] = {
        0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x7f01002f
    };
    public static final int MenuView_android_headerBackground = 4;
    public static final int MenuView_android_horizontalDivider = 2;
    public static final int MenuView_android_itemBackground = 5;
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    public static final int MenuView_android_itemTextAppearance = 1;
    public static final int MenuView_android_verticalDivider = 3;
    public static final int MenuView_android_windowAnimationStyle = 0;
    public static final int MenuView_preserveIconSpacing = 7;
    public static final int PopupWindow[] = {
        0x1010176, 0x7f010030
    };
    public static final int PopupWindowBackgroundState[] = {
        0x7f010031
    };
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    public static final int PopupWindow_android_popupBackground = 0;
    public static final int PopupWindow_overlapAnchor = 1;
    public static final int SearchView[] = {
        0x10100da, 0x101011f, 0x1010220, 0x1010264, 0x7f010032, 0x7f010033, 0x7f010034, 0x7f010035, 0x7f010036, 0x7f010037, 
        0x7f010038, 0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c
    };
    public static final int SearchView_android_focusable = 0;
    public static final int SearchView_android_imeOptions = 3;
    public static final int SearchView_android_inputType = 2;
    public static final int SearchView_android_maxWidth = 1;
    public static final int SearchView_closeIcon = 7;
    public static final int SearchView_commitIcon = 11;
    public static final int SearchView_goIcon = 8;
    public static final int SearchView_iconifiedByDefault = 5;
    public static final int SearchView_layout = 4;
    public static final int SearchView_queryBackground = 13;
    public static final int SearchView_queryHint = 6;
    public static final int SearchView_searchIcon = 9;
    public static final int SearchView_submitBackground = 14;
    public static final int SearchView_suggestionRowLayout = 12;
    public static final int SearchView_voiceIcon = 10;
    public static final int Spinner[] = {
        0x10100af, 0x10100d4, 0x1010175, 0x1010176, 0x1010262, 0x10102ac, 0x10102ad, 0x7f01003d, 0x7f01003e, 0x7f01003f, 
        0x7f010040
    };
    public static final int Spinner_android_background = 1;
    public static final int Spinner_android_dropDownHorizontalOffset = 5;
    public static final int Spinner_android_dropDownSelector = 2;
    public static final int Spinner_android_dropDownVerticalOffset = 6;
    public static final int Spinner_android_dropDownWidth = 4;
    public static final int Spinner_android_gravity = 0;
    public static final int Spinner_android_popupBackground = 3;
    public static final int Spinner_disableChildrenWhenDisabled = 10;
    public static final int Spinner_popupPromptView = 9;
    public static final int Spinner_prompt = 7;
    public static final int Spinner_spinnerMode = 8;
    public static final int SwitchCompat[] = {
        0x1010124, 0x1010125, 0x1010142, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 0x7f010047
    };
    public static final int SwitchCompat_android_textOff = 1;
    public static final int SwitchCompat_android_textOn = 0;
    public static final int SwitchCompat_android_thumb = 2;
    public static final int SwitchCompat_showText = 9;
    public static final int SwitchCompat_splitTrack = 8;
    public static final int SwitchCompat_switchMinWidth = 6;
    public static final int SwitchCompat_switchPadding = 7;
    public static final int SwitchCompat_switchTextAppearance = 5;
    public static final int SwitchCompat_thumbTextPadding = 4;
    public static final int SwitchCompat_track = 3;
    public static final int Theme[] = {
        0x1010057, 0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c, 0x7f01004d, 0x7f01004e, 0x7f01004f, 0x7f010050, 
        0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054, 0x7f010055, 0x7f010056, 0x7f010057, 0x7f010058, 0x7f010059, 0x7f01005a, 
        0x7f01005b, 0x7f01005c, 0x7f01005d, 0x7f01005e, 0x7f01005f, 0x7f010060, 0x7f010061, 0x7f010062, 0x7f010063, 0x7f010064, 
        0x7f010065, 0x7f010066, 0x7f010067, 0x7f010068, 0x7f010069, 0x7f01006a, 0x7f01006b, 0x7f01006c, 0x7f01006d, 0x7f01006e, 
        0x7f01006f, 0x7f010070, 0x7f010071, 0x7f010072, 0x7f010073, 0x7f010074, 0x7f010075, 0x7f010076, 0x7f010077, 0x7f010078, 
        0x7f010079, 0x7f01007a, 0x7f01007b, 0x7f01007c, 0x7f01007d, 0x7f01007e, 0x7f01007f, 0x7f010080, 0x7f010081, 0x7f010082, 
        0x7f010083, 0x7f010084, 0x7f010085, 0x7f010086, 0x7f010087, 0x7f010088, 0x7f010089, 0x7f01008a, 0x7f01008b, 0x7f01008c, 
        0x7f01008d, 0x7f01008e, 0x7f01008f, 0x7f010090, 0x7f010091, 0x7f010092, 0x7f010093, 0x7f010094, 0x7f010095, 0x7f010096, 
        0x7f010097, 0x7f010098, 0x7f010099
    };
    public static final int Theme_actionBarDivider = 19;
    public static final int Theme_actionBarItemBackground = 20;
    public static final int Theme_actionBarPopupTheme = 13;
    public static final int Theme_actionBarSize = 18;
    public static final int Theme_actionBarSplitStyle = 15;
    public static final int Theme_actionBarStyle = 14;
    public static final int Theme_actionBarTabBarStyle = 9;
    public static final int Theme_actionBarTabStyle = 8;
    public static final int Theme_actionBarTabTextStyle = 10;
    public static final int Theme_actionBarTheme = 16;
    public static final int Theme_actionBarWidgetTheme = 17;
    public static final int Theme_actionButtonStyle = 43;
    public static final int Theme_actionDropDownStyle = 38;
    public static final int Theme_actionMenuTextAppearance = 21;
    public static final int Theme_actionMenuTextColor = 22;
    public static final int Theme_actionModeBackground = 25;
    public static final int Theme_actionModeCloseButtonStyle = 24;
    public static final int Theme_actionModeCloseDrawable = 27;
    public static final int Theme_actionModeCopyDrawable = 29;
    public static final int Theme_actionModeCutDrawable = 28;
    public static final int Theme_actionModeFindDrawable = 33;
    public static final int Theme_actionModePasteDrawable = 30;
    public static final int Theme_actionModePopupWindowStyle = 35;
    public static final int Theme_actionModeSelectAllDrawable = 31;
    public static final int Theme_actionModeShareDrawable = 32;
    public static final int Theme_actionModeSplitBackground = 26;
    public static final int Theme_actionModeStyle = 23;
    public static final int Theme_actionModeWebSearchDrawable = 34;
    public static final int Theme_actionOverflowButtonStyle = 11;
    public static final int Theme_actionOverflowMenuStyle = 12;
    public static final int Theme_activityChooserViewStyle = 50;
    public static final int Theme_android_windowIsFloating = 0;
    public static final int Theme_buttonBarButtonStyle = 45;
    public static final int Theme_buttonBarStyle = 44;
    public static final int Theme_colorAccent = 77;
    public static final int Theme_colorButtonNormal = 81;
    public static final int Theme_colorControlActivated = 79;
    public static final int Theme_colorControlHighlight = 80;
    public static final int Theme_colorControlNormal = 78;
    public static final int Theme_colorPrimary = 75;
    public static final int Theme_colorPrimaryDark = 76;
    public static final int Theme_colorSwitchThumbNormal = 82;
    public static final int Theme_dividerHorizontal = 49;
    public static final int Theme_dividerVertical = 48;
    public static final int Theme_dropDownListViewStyle = 67;
    public static final int Theme_dropdownListPreferredItemHeight = 39;
    public static final int Theme_editTextBackground = 56;
    public static final int Theme_editTextColor = 55;
    public static final int Theme_homeAsUpIndicator = 42;
    public static final int Theme_listChoiceBackgroundIndicator = 74;
    public static final int Theme_listPopupWindowStyle = 68;
    public static final int Theme_listPreferredItemHeight = 62;
    public static final int Theme_listPreferredItemHeightLarge = 64;
    public static final int Theme_listPreferredItemHeightSmall = 63;
    public static final int Theme_listPreferredItemPaddingLeft = 65;
    public static final int Theme_listPreferredItemPaddingRight = 66;
    public static final int Theme_panelBackground = 71;
    public static final int Theme_panelMenuListTheme = 73;
    public static final int Theme_panelMenuListWidth = 72;
    public static final int Theme_popupMenuStyle = 53;
    public static final int Theme_popupWindowStyle = 54;
    public static final int Theme_searchViewStyle = 61;
    public static final int Theme_selectableItemBackground = 46;
    public static final int Theme_selectableItemBackgroundBorderless = 47;
    public static final int Theme_spinnerDropDownItemStyle = 41;
    public static final int Theme_spinnerStyle = 40;
    public static final int Theme_switchStyle = 57;
    public static final int Theme_textAppearanceLargePopupMenu = 36;
    public static final int Theme_textAppearanceListItem = 69;
    public static final int Theme_textAppearanceListItemSmall = 70;
    public static final int Theme_textAppearanceSearchResultSubtitle = 59;
    public static final int Theme_textAppearanceSearchResultTitle = 58;
    public static final int Theme_textAppearanceSmallPopupMenu = 37;
    public static final int Theme_textColorSearchUrl = 60;
    public static final int Theme_toolbarNavigationButtonStyle = 52;
    public static final int Theme_toolbarStyle = 51;
    public static final int Theme_windowActionBar = 1;
    public static final int Theme_windowActionBarOverlay = 2;
    public static final int Theme_windowActionModeOverlay = 3;
    public static final int Theme_windowFixedHeightMajor = 7;
    public static final int Theme_windowFixedHeightMinor = 5;
    public static final int Theme_windowFixedWidthMajor = 4;
    public static final int Theme_windowFixedWidthMinor = 6;
    public static final int Toolbar[] = {
        0x10100af, 0x1010140, 0x7f010003, 0x7f010006, 0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001b, 0x7f01009a, 
        0x7f01009b, 0x7f01009c, 0x7f01009d, 0x7f01009e, 0x7f01009f, 0x7f0100a0, 0x7f0100a1, 0x7f0100a2, 0x7f0100a3, 0x7f0100a4, 
        0x7f0100a5, 0x7f0100a6
    };
    public static final int Toolbar_android_gravity = 0;
    public static final int Toolbar_android_minHeight = 1;
    public static final int Toolbar_collapseContentDescription = 19;
    public static final int Toolbar_collapseIcon = 18;
    public static final int Toolbar_contentInsetEnd = 5;
    public static final int Toolbar_contentInsetLeft = 6;
    public static final int Toolbar_contentInsetRight = 7;
    public static final int Toolbar_contentInsetStart = 4;
    public static final int Toolbar_maxButtonHeight = 16;
    public static final int Toolbar_navigationContentDescription = 21;
    public static final int Toolbar_navigationIcon = 20;
    public static final int Toolbar_popupTheme = 8;
    public static final int Toolbar_subtitle = 3;
    public static final int Toolbar_subtitleTextAppearance = 10;
    public static final int Toolbar_theme = 17;
    public static final int Toolbar_title = 2;
    public static final int Toolbar_titleMarginBottom = 15;
    public static final int Toolbar_titleMarginEnd = 13;
    public static final int Toolbar_titleMarginStart = 12;
    public static final int Toolbar_titleMarginTop = 14;
    public static final int Toolbar_titleMargins = 11;
    public static final int Toolbar_titleTextAppearance = 9;
    public static final int View[] = {
        0x10100da, 0x7f0100a7, 0x7f0100a8
    };
    public static final int ViewStubCompat[] = {
        0x10100d0, 0x10100f2, 0x10100f3
    };
    public static final int ViewStubCompat_android_id = 0;
    public static final int ViewStubCompat_android_inflatedId = 2;
    public static final int ViewStubCompat_android_layout = 1;
    public static final int View_android_focusable = 0;
    public static final int View_paddingEnd = 2;
    public static final int View_paddingStart = 1;


    public ()
    {
    }
}
