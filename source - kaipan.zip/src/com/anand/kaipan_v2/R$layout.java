// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


// Referenced classes of package com.anand.kaipan_v2:
//            R

public static final class 
{

    public static final int abc_action_bar_title_item = 0x7f030000;
    public static final int abc_action_bar_up_container = 0x7f030001;
    public static final int abc_action_bar_view_list_nav_layout = 0x7f030002;
    public static final int abc_action_menu_item_layout = 0x7f030003;
    public static final int abc_action_menu_layout = 0x7f030004;
    public static final int abc_action_mode_bar = 0x7f030005;
    public static final int abc_action_mode_close_item_material = 0x7f030006;
    public static final int abc_activity_chooser_view = 0x7f030007;
    public static final int abc_activity_chooser_view_include = 0x7f030008;
    public static final int abc_activity_chooser_view_list_item = 0x7f030009;
    public static final int abc_expanded_menu_layout = 0x7f03000a;
    public static final int abc_list_menu_item_checkbox = 0x7f03000b;
    public static final int abc_list_menu_item_icon = 0x7f03000c;
    public static final int abc_list_menu_item_layout = 0x7f03000d;
    public static final int abc_list_menu_item_radio = 0x7f03000e;
    public static final int abc_popup_menu_item_layout = 0x7f03000f;
    public static final int abc_screen_content_include = 0x7f030010;
    public static final int abc_screen_simple = 0x7f030011;
    public static final int abc_screen_simple_overlay_action_mode = 0x7f030012;
    public static final int abc_screen_toolbar = 0x7f030013;
    public static final int abc_search_dropdown_item_icons_2line = 0x7f030014;
    public static final int abc_search_view = 0x7f030015;
    public static final int abc_simple_dropdown_hint = 0x7f030016;
    public static final int activity_main = 0x7f030017;
    public static final int support_simple_spinner_dropdown_item = 0x7f030018;

    public ()
    {
    }
}
