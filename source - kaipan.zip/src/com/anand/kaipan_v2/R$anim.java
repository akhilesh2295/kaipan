// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


// Referenced classes of package com.anand.kaipan_v2:
//            R

public static final class 
{

    public static final int abc_fade_in = 0x7f040000;
    public static final int abc_fade_out = 0x7f040001;
    public static final int abc_slide_in_bottom = 0x7f040002;
    public static final int abc_slide_in_top = 0x7f040003;
    public static final int abc_slide_out_bottom = 0x7f040004;
    public static final int abc_slide_out_top = 0x7f040005;

    public ()
    {
    }
}
