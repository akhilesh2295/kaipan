// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.anand.kaipan_v2;


// Referenced classes of package com.anand.kaipan_v2:
//            R

public static final class 
{

    public static final int abc_action_bar_default_height_material = 0x7f080000;
    public static final int abc_action_bar_default_padding_material = 0x7f080001;
    public static final int abc_action_bar_icon_vertical_padding_material = 0x7f080002;
    public static final int abc_action_bar_progress_bar_size = 0x7f080003;
    public static final int abc_action_bar_stacked_max_height = 0x7f080004;
    public static final int abc_action_bar_stacked_tab_max_width = 0x7f080005;
    public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f080006;
    public static final int abc_action_bar_subtitle_top_margin_material = 0x7f080007;
    public static final int abc_action_button_min_height_material = 0x7f080008;
    public static final int abc_action_button_min_width_material = 0x7f080009;
    public static final int abc_action_button_min_width_overflow_material = 0x7f08000a;
    public static final int abc_config_prefDialogWidth = 0x7f08000b;
    public static final int abc_control_inset_material = 0x7f08000c;
    public static final int abc_control_padding_material = 0x7f08000d;
    public static final int abc_dropdownitem_icon_width = 0x7f08000e;
    public static final int abc_dropdownitem_text_padding_left = 0x7f08000f;
    public static final int abc_dropdownitem_text_padding_right = 0x7f080010;
    public static final int abc_panel_menu_list_width = 0x7f080011;
    public static final int abc_search_view_preferred_width = 0x7f080012;
    public static final int abc_search_view_text_min_width = 0x7f080013;
    public static final int abc_text_size_body_1_material = 0x7f080014;
    public static final int abc_text_size_body_2_material = 0x7f080015;
    public static final int abc_text_size_button_material = 0x7f080016;
    public static final int abc_text_size_caption_material = 0x7f080017;
    public static final int abc_text_size_display_1_material = 0x7f080018;
    public static final int abc_text_size_display_2_material = 0x7f080019;
    public static final int abc_text_size_display_3_material = 0x7f08001a;
    public static final int abc_text_size_display_4_material = 0x7f08001b;
    public static final int abc_text_size_headline_material = 0x7f08001c;
    public static final int abc_text_size_large_material = 0x7f08001d;
    public static final int abc_text_size_medium_material = 0x7f08001e;
    public static final int abc_text_size_menu_material = 0x7f08001f;
    public static final int abc_text_size_small_material = 0x7f080020;
    public static final int abc_text_size_subhead_material = 0x7f080021;
    public static final int abc_text_size_subtitle_material_toolbar = 0x7f080022;
    public static final int abc_text_size_title_material = 0x7f080023;
    public static final int abc_text_size_title_material_toolbar = 0x7f080024;
    public static final int activity_horizontal_margin = 0x7f080025;
    public static final int activity_vertical_margin = 0x7f080026;
    public static final int dialog_fixed_height_major = 0x7f080027;
    public static final int dialog_fixed_height_minor = 0x7f080028;
    public static final int dialog_fixed_width_major = 0x7f080029;
    public static final int dialog_fixed_width_minor = 0x7f08002a;
    public static final int disabled_alpha_material_dark = 0x7f08002b;
    public static final int disabled_alpha_material_light = 0x7f08002c;

    public ()
    {
    }
}
